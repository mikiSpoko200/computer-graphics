
// pub struct Triangle {
//
// }
//
// pub struct Triangular {
//     base:
// }